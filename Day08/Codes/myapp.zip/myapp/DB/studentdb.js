let students = [
    {regno:'2021ICT01',name:'Jennie',age:21,gender:'female',course:'IT'},
    {regno:'2021BIO01',name:'Rose',age:20,gender:'female',course:'BIO'},
    {regno:'2021ICT02',name:'Jisoo',age:22,gender:'female',course:'IT'},
    {regno:'2021AMC01',name:'Felix',age:20,gender:'male',course:'Maths'},
    {regno:'2021ICT03',name:'Kai',age:21,gender:'male',course:'IT'},
    {regno:'2021BIO01',name:'Dino',age:23,gender:'male',course:'BIO'}

];

module.exports=students;