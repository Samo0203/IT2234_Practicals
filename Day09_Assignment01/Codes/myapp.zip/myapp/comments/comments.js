const comments = [
    { id: 1, postId: '1', userId: '2', content: 'Great tips! I will definitely try these out.', createdAt: '2022-04-10' },
    { id: 2, postId: '1', userId: '3', content: 'Thanks for sharing. It\'s important to prioritize health.', createdAt: '2022-04-11' },
    { id: 3, postId: '2', userId: '1', content: 'The Grand Canyon is breathtaking. Can\'t wait to visit again.', createdAt: '2022-04-13' },
    { id: 4, postId: '3', userId: '2', content: 'Yoga has changed my life. It\'s so beneficial for mental and physical health.', createdAt: '2022-04-16' },
    { id: 5, postId: '4', userId: '4', content: 'Traveling on a budget is possible with careful planning. Thanks for the tips!', createdAt: '2022-04-19' }
  ];

module.exports=comments;